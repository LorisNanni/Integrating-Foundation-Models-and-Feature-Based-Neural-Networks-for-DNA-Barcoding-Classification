# BarcodeMAE for DNA Barcoding Classification

This repository accompanies *"Integrating Foundation Models and Feature-Based Neural Networks
for DNA Barcoding Classification"* (Nanni, Fusaro, Carraro & Brahnam — see
[Citation](#citation)). It bundles:

* **[`BarcodeMAE/`](BarcodeMAE/)** — a modified copy of
  [bioscan-ml/BarcodeMAE](https://github.com/bioscan-ml/BarcodeMAE), a masked-autoencoder
  foundation model for DNA barcode sequences. Its dataloader (`barcodebert/datasets.py`) was
  extended to read plain FASTA files, and its fine-tuning script (`barcodebert/finetuning.py`)
  to fine-tune on them, so that the pretrained encoder can be used on the many additional
  barcode datasets evaluated in the paper (birds, fishes, bats, beetle/fish k-fold
  cross-validation, simulated noise-robustness datasets, ...) instead of only the two dataset
  formats the original code shipped with.
* **[`finetune_scripts/`](finetune_scripts/)** — convenience command-line tools built on top of
  that extended dataloader: fine-tune a pretrained checkpoint on any of those datasets
  (`train.py`), re-score a checkpoint without retraining (`evaluate.py`), and use any checkpoint
  purely as a feature extractor (`extract_features.py`). See its
  [README](finetune_scripts/README.md) for full usage instructions.

## Quick start

```shell
# clone this repo
# git clone ...

pip install -r BarcodeMAE/requirements.txt
pip install biopython scipy   # FASTA parsing + .mat cross-validation folds, used by finetune_scripts/
```

* To pretrain a BarcodeMAE encoder from scratch, or reproduce the original BarcodeMAE
  benchmarks, follow [`BarcodeMAE/README.md`](BarcodeMAE/README.md).
* To fine-tune, evaluate, or extract features from a pretrained checkpoint on any of the
  datasets used in the paper, follow [`finetune_scripts/README.md`](finetune_scripts/README.md).

## Relationship to upstream BarcodeMAE

`BarcodeMAE/` starts from [bioscan-ml/BarcodeMAE](https://github.com/bioscan-ml/BarcodeMAE) and
changes four files to add FASTA-dataset support, without touching the model architecture or the
pretraining code:

* `barcodebert/datasets.py` — `DNADataset` reads arbitrary FASTA files (via BioPython) instead
  of only BIOSCAN's own CSV/TSV format, with per-dataset rules for extracting the
  species/genus label from each FASTA header, optional index-based subsetting for k-fold
  cross-validation, and reuse of the training split's label mapping for validation/test splits.
* `barcodebert/finetuning.py` — adds k-fold cross-validation (`--k-folds`/`--crossval-fold`)
  and a "run over 100 simulated datasets" mode, on top of the original single-dataset
  fine-tuning loop.
* `barcodebert/io.py` — loads a pretrained checkpoint with `strict=False`, so it tolerates a
  state dict that doesn't perfectly match the current model (e.g. a different classification
  head).
* `requirements.txt` — updated dependency versions, plus `biopython`.

`finetune_scripts/` does not modify any of BarcodeMAE's code; it imports `barcodebert` as a
library and adds a complete, consistent dataset → file-path registry on top of it (see
[`finetune_scripts/README.md`](finetune_scripts/README.md#notes-on-the-upstream-codebase) for
two small gaps in the original per-dataset lookup that registry fixes).

## License

MIT, same as upstream BarcodeMAE — see [`BarcodeMAE/LICENSE`](BarcodeMAE/LICENSE).

## Citation

If you use this repository, please cite the paper it was built for:

```latex
@article{nanni2026integrating,
  title   = {Integrating Foundation Models and Feature-Based Neural Networks for {DNA} Barcoding Classification},
  author  = {Nanni, Loris and Fusaro, Daniel and Carraro, Eddie and Brahnam, Sheryl},
  journal = {Computational Biology and Chemistry},
  year    = {2026},
  note    = {Manuscript submitted for publication},
}
```

Please also cite BarcodeMAE itself, whose pretrained encoder and dataloader this repository builds on:

```latex
@article{safari2025barcodemae,
  title         = {Enhancing DNA Foundation Models to Address Masking Inefficiencies},
  author        = {Safari, Monireh and Millan Arias, Pablo and Lowe, Scott C. and Kari, Lila and Chang, Angel X. and Taylor, Graham W.},
  journal       = {arXiv preprint arXiv:2502.18405},
  year          = {2025},
  eprint        = {2502.18405},
  archivePrefix = {arXiv},
  primaryClass  = {cs.LG},
  doi           = {10.48550/arXiv.2502.18405},
}
```
