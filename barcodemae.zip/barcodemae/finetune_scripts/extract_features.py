#!/usr/bin/env python
"""
Extract BarcodeMAE/BarcodeBERT features (embeddings) for a set of DNA
barcodes, using *any* checkpoint - a raw pretrained checkpoint (e.g.
best_pretraining.pt) or a fine-tuned one produced by train.py - and save
them as a plain-text feature matrix (one feature vector per row), with
numpy.savetxt.

For each barcode, the feature vector is the attention-mask-weighted mean
(over non-padding tokens) of the encoder's last hidden state - the same
pooling barcodebert.datasets.representations_from_df uses for the project's
existing kNN/feature-based classifiers.

Usage:
    # Any FASTA file, any checkpoint:
    python extract_features.py --checkpoint <ckpt.pt> --input sequences.fasta --output features.txt

    # Or use the dataset registry (same --dataset names as train.py/evaluate.py):
    python extract_features.py --checkpoint <ckpt.pt> --dataset birds --output birds_features.txt

Run `python extract_features.py --list-datasets` for the registry-based options.
"""

import argparse
import os
import sys
from itertools import product

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_BARCODEMAE_ROOT = os.environ.get("BARCODEMAE_ROOT") or os.path.normpath(os.path.join(_HERE, "..", "BarcodeMAE"))
if _BARCODEMAE_ROOT not in sys.path:
    sys.path.insert(0, _BARCODEMAE_ROOT)
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import dataset_paths as dp  # noqa: E402

from Bio import SeqIO  # noqa: E402
from torch.utils.data import DataLoader, Dataset  # noqa: E402
from torchtext.vocab import vocab as build_vocab_from_dict  # noqa: E402
from transformers import BertConfig, BertForTokenClassification, BertModel  # noqa: E402

from barcodebert.datasets import BPETokenizer, KmerTokenizer  # noqa: E402
from barcodebert.utils import remove_extra_pre_fix  # noqa: E402


class SequenceDataset(Dataset):
    """Tokenizes raw barcodes for feature extraction (no label parsing: works on any FASTA file)."""

    def __init__(self, records, k_mer, stride, tokenizer_name, bpe_path, tokenize_n_nucleotide, max_len):
        self.ids = [r[0] for r in records]
        self.barcodes = [r[1] for r in records]
        self.k_mer = k_mer
        self.stride = stride or k_mer

        if not max_len:
            max_len = max(len(b) for b in self.barcodes)
            print(f"Maximum barcode length in the input: {max_len}")
        self.max_len = max_len

        if tokenizer_name == "kmer":
            base_pairs = "ACGT"
            special_tokens = ["[MASK]", "[UNK]"]
            unk_token = "[UNK]"
            if tokenize_n_nucleotide:
                base_pairs += "N"
            kmers = ["".join(kmer) for kmer in product(base_pairs, repeat=k_mer)]
            if tokenize_n_nucleotide:
                kmers = [km for km in kmers if "N" not in km] + [km for km in kmers if "N" in km]
            kmer_dict = dict.fromkeys(kmers, 1)
            vocab = build_vocab_from_dict(kmer_dict, specials=special_tokens)
            vocab.set_default_index(vocab[unk_token])
            self.tokenizer = KmerTokenizer(k_mer, vocab, max_len=self.max_len, stride=self.stride, padding=True)
        elif tokenizer_name == "bpe":
            self.tokenizer = BPETokenizer(padding=True, max_tokenized_len=self.max_len, bpe_path=bpe_path)
        else:
            raise ValueError(f'Tokenizer "{tokenizer_name}" not recognized.')

    def __len__(self):
        return len(self.barcodes)

    def __getitem__(self, idx):
        tokens, att_mask = self.tokenizer(self.barcodes[idx])
        return tokens, att_mask


def load_any_encoder(checkpoint_path, device):
    """
    Load the encoder from *any* BarcodeMAE/BarcodeBERT checkpoint: a raw
    pretrained checkpoint (barcodebert/pretraining.py's own output, e.g.
    best_pretraining.pt) or a fine-tuned one (train.py's output, or
    barcodebert/finetuning.py's). Only the encoder is returned; any
    classification head is dropped.
    """
    print(f"Loading checkpoint from {checkpoint_path}")
    ckpt = torch.load(checkpoint_path, map_location=device, weights_only=False)
    bert_config = BertConfig(**ckpt["bert_config"])
    arch = ckpt["config"].arch
    if arch == "maelm":
        model = BertModel(bert_config)
    elif arch == "transformer":
        model = BertForTokenClassification(bert_config)
    else:
        raise ValueError(f"Unrecognized arch {arch!r} in checkpoint {checkpoint_path}.")

    state = remove_extra_pre_fix(ckpt["model"])
    if any(k.startswith("base_model.") for k in state):
        # A fine-tuned ClassificationModel checkpoint (train.py / finetuning.py):
        # keep only the encoder weights, drop the "classifier.*" head.
        state = {k[len("base_model."):]: v for k, v in state.items() if k.startswith("base_model.")}
    model.load_state_dict(state, strict=False)
    model.to(device)
    model.eval()
    print(f"  arch={arch}  hidden_size={bert_config.hidden_size}  k_mer={ckpt['config'].k_mer}")
    return model, ckpt["config"]


def read_fasta(path):
    print(f"Reading {path}")
    records = [(record.description, str(record.seq).upper()) for record in SeqIO.parse(path, "fasta")]
    print(f"  {len(records)} sequences")
    return records


def resolve_input_files(args):
    """Return a list of FASTA file paths to read sequences from, in order."""
    if args.input:
        return [args.input]

    kind = dp.dataset_kind(args.dataset)
    if kind == "simple":
        train_path, test_path = dp.resolve_simple(args.dataset, args.data_dir)
    elif kind == "crossval":
        # A single file holds every sequence; k-fold splitting only matters for
        # training, not for raw feature extraction, so we just read it whole.
        seq_path, _mat_path = dp.resolve_crossval_files(args.dataset, args.data_dir, args.crossval_fold_path)
        return [seq_path]
    elif kind == "simulated":
        if args.simulated_type is None:
            raise SystemExit(
                f"--simulated-type is required for simulated dataset {args.dataset!r} (choose one of {dp.SIMULATED_TYPES})."
            )
        fold_index = args.fold if args.fold is not None else 0
        if args.fold is None:
            print(f"--fold not given for a simulated dataset; defaulting to replicate 0.")
        train_path, test_path = dp.resolve_simulated_files(args.dataset, args.data_dir, args.simulated_type, fold_index)
    else:
        raise AssertionError(f"Unhandled dataset kind {kind!r}")

    if args.split == "train":
        return [train_path]
    if args.split == "test":
        return [test_path]
    return [train_path, test_path]  # "all"


@torch.no_grad()
def extract_features(model, dataset, device, batch_size):
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    all_features = []
    n_done = 0
    for tokens, att_mask in loader:
        tokens = tokens.to(device)
        att_mask = att_mask.to(device)
        outputs = model(input_ids=tokens, attention_mask=att_mask, output_hidden_states=True)
        hidden = outputs.hidden_states[-1]  # (B, L, H)
        mask = att_mask.unsqueeze(-1).to(hidden.dtype)  # (B, L, 1), excludes padding tokens
        summed = (hidden * mask).sum(1)
        counts = mask.sum(1).clamp(min=1)
        features = summed / counts  # masked mean pooling over the sequence length
        all_features.append(features.cpu().numpy())
        n_done += tokens.shape[0]
        print(f"  extracted features for {n_done}/{len(dataset)} sequences", end="\r", flush=True)
    print()
    return np.concatenate(all_features, axis=0)


def build_arg_parser():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--list-datasets", action="store_true", help="Print all supported --dataset values and exit.")

    g = parser.add_argument_group("Model")
    g.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="Path to any BarcodeMAE/BarcodeBERT checkpoint: a pretrained one (e.g. best_pretraining.pt) "
        "or a fine-tuned one (e.g. from train.py). Required unless --list-datasets.",
    )

    g = parser.add_argument_group("Input sequences (choose one)")
    g.add_argument("--input", type=str, default=None, help="Path to any FASTA file of DNA barcodes.")
    g.add_argument("--dataset", type=str, default=None, help="Dataset name from the registry (see --list-datasets).")
    g.add_argument("--data-dir", type=str, default="/home/velazquez/dna_foundation/clean_code/data")
    g.add_argument(
        "--split",
        type=str,
        choices=["train", "test", "all"],
        default="all",
        help="Which split(s) of --dataset to read (ignored with --input, and for k-fold datasets "
        "which have no train/test distinction).",
    )
    g.add_argument("--simulated-type", type=str, choices=dp.SIMULATED_TYPES, default=None)
    g.add_argument("--crossval-fold", dest="crossval_fold_path", type=str, default=None)
    g.add_argument("--fold", type=int, default=None, help="Replicate index for a simulated dataset (default: 0).")

    g = parser.add_argument_group("Output")
    g.add_argument("--output", type=str, default=None, help="Path to write the feature matrix to (required unless --list-datasets).")
    g.add_argument("--save-ids", type=str, default=None, help="Optional: also write the FASTA header of each row, one per line, in the same order.")
    g.add_argument("--fmt", type=str, default="%.6f", help="numpy.savetxt format string for the features.")

    g = parser.add_argument_group("Run")
    g.add_argument("--batch-size", type=int, default=32)
    g.add_argument("--no-cuda", action="store_true")

    return parser


def main():
    parser = build_arg_parser()
    args = parser.parse_args()

    if args.list_datasets:
        print(dp.describe())
        return

    if not args.checkpoint:
        parser.error("--checkpoint is required.")
    if not args.input and not args.dataset:
        parser.error("Either --input <fasta file> or --dataset <name> is required.")
    if args.input and args.dataset:
        parser.error("Pass only one of --input or --dataset, not both.")
    if not args.output:
        parser.error("--output is required.")

    device = torch.device("cuda" if (not args.no_cuda and torch.cuda.is_available()) else "cpu")
    print(f"Using device {device}")

    model, config = load_any_encoder(args.checkpoint, device)

    input_paths = resolve_input_files(args)
    records = []
    for path in input_paths:
        records.extend(read_fasta(path))
    if not records:
        raise SystemExit("No sequences found to extract features from.")

    dataset = SequenceDataset(
        records,
        k_mer=config.k_mer,
        stride=config.stride,
        tokenizer_name=config.tokenizer,
        bpe_path=config.bpe_path,
        tokenize_n_nucleotide=config.tokenize_n_nucleotide,
        max_len=0,
    )

    print(f"Extracting features for {len(dataset)} sequences (feature dim {model.config.hidden_size})...")
    features = extract_features(model, dataset, device, args.batch_size)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)) or ".", exist_ok=True)
    np.savetxt(args.output, features, fmt=args.fmt)
    print(f"Saved {features.shape[0]} feature vectors of dimension {features.shape[1]} to {args.output}")

    if args.save_ids:
        with open(args.save_ids, "w") as f:
            f.write("\n".join(dataset.ids) + "\n")
        print(f"Saved {len(dataset.ids)} sequence identifiers to {args.save_ids}")


if __name__ == "__main__":
    main()
