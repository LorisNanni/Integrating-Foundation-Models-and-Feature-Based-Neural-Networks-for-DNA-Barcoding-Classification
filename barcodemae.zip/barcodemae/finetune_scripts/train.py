#!/usr/bin/env python
"""
Fine-tune a pretrained BarcodeMAE/BarcodeBERT encoder on any of the FASTA
datasets supported by ``barcodebert.datasets.DNADataset`` (the dataloader
written for "Integrating Foundation Models and Feature-Based Neural Networks
for DNA Barcoding Classification").

This script lives next to (not inside) the BarcodeMAE/ checkout, which is
read-only, and imports its `barcodebert` package as a library. It is a
dataset-aware convenience wrapper around the building blocks in
barcodebert.finetuning / barcodebert.datasets / barcodebert.evaluation /
barcodebert.io - it does not modify or duplicate their core logic (the model,
the training step, the evaluation metrics), it only replaces the fragile,
partial per-dataset file lookup that lives inside finetuning.run() with the
complete registry in dataset_paths.py, and adds a simple CLI on top.

See README.md in this directory for usage examples, or run:
    python train.py --list-datasets
"""

import argparse
import os
import sys
import time
from datetime import datetime

import numpy as np
import torch
from torch import nn

_HERE = os.path.dirname(os.path.abspath(__file__))
_BARCODEMAE_ROOT = os.environ.get("BARCODEMAE_ROOT") or os.path.normpath(os.path.join(_HERE, "..", "BarcodeMAE"))
if _BARCODEMAE_ROOT not in sys.path:
    sys.path.insert(0, _BARCODEMAE_ROOT)
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import dataset_paths as dp  # noqa: E402  (local module, must come after sys.path setup)

from barcodebert import utils  # noqa: E402
from barcodebert.datasets import DNADataset  # noqa: E402
from barcodebert.evaluation import evaluate  # noqa: E402
from barcodebert.finetuning import BASE_BATCH_SIZE, ClassificationModel, get_parser  # noqa: E402
from barcodebert.finetuning import train_one_epoch  # noqa: E402
from barcodebert.io import load_pretrained_model, safe_save_model  # noqa: E402


def build_arg_parser():
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--list-datasets", action="store_true", help="Print all supported datasets and exit.")

    g = parser.add_argument_group("Data")
    g.add_argument("--dataset", type=str, help="Dataset name. See --list-datasets.")
    g.add_argument(
        "--data-dir",
        type=str,
        default="/home/velazquez/dna_foundation/clean_code/data",
        help="Root directory containing the dataset FASTA/mat files.",
    )
    g.add_argument(
        "--simulated-type",
        type=str,
        choices=dp.SIMULATED_TYPES,
        default=None,
        help="Required when --dataset is a simulated GNe<size> dataset.",
    )
    g.add_argument(
        "--crossval-fold",
        dest="crossval_fold_path",
        type=str,
        default=None,
        help="Path to the .mat file with train/test indices. Only for beetle/fish; "
        "defaults to data-dir/splitBeetle.mat or data-dir/splitFish.mat.",
    )

    g = parser.add_argument_group("Fold / replicate selection")
    g.add_argument(
        "--k-folds",
        type=int,
        default=None,
        help="Number of folds to run for k-fold or simulated datasets. Defaults to all folds available "
        "(10 for beetle/fish, 100 for GNe* simulated datasets). Ignored for simple-split datasets.",
    )
    g.add_argument(
        "--fold",
        type=int,
        default=None,
        help="Run only this single fold/replicate index (0-based) instead of looping over all of them.",
    )

    g = parser.add_argument_group("Model")
    g.add_argument("--pretrained-checkpoint", type=str, default=None, help="Path to a pretrained BarcodeMAE/BarcodeBERT checkpoint (required unless --list-datasets).")
    g.add_argument("--freeze-encoder", action="store_true", help="Freeze the encoder and only train the classification head (linear probing).")

    g = parser.add_argument_group("Optimization")
    g.add_argument("--epochs", type=int, default=50)
    g.add_argument("--batch-size-per-gpu", "--batch-size", dest="batch_size_per_gpu", type=int, default=16)
    g.add_argument("--lr", dest="lr_relative", type=float, default=0.0001, help=f"Max LR, scaled per {BASE_BATCH_SIZE} batch size (OneCycle).")
    g.add_argument("--weight-decay", type=float, default=0.00001)
    g.add_argument("--optimizer", type=str, default="AdamW")
    g.add_argument("--scheduler", type=str, default="OneCycle", choices=["OneCycle"])
    g.add_argument("--skip-validation", action="store_true", help="Skip the per-epoch evaluation pass (only evaluate at the end).")

    g = parser.add_argument_group("Output")
    g.add_argument("--output-dir", type=str, default="model_checkpoints", help="Where to save finetuned checkpoints.")
    g.add_argument("--run-name", type=str, default=None)
    g.add_argument("--no-save-best-model", action="store_true", help="Do not keep a separate copy of the best-performing epoch.")

    g = parser.add_argument_group("Logging")
    g.add_argument("--log-wandb", action="store_true")
    g.add_argument("--wandb-entity", type=str, default="uoguelph_mlrg")
    g.add_argument("--wandb-project", type=str, default="BarcodeBERT")
    g.add_argument("--log-interval", type=int, default=100)

    g = parser.add_argument_group("Hardware / reproducibility")
    g.add_argument("--seed", type=int, default=None)
    g.add_argument("--no-cuda", action="store_true")
    g.add_argument("--cpu-workers", type=int, default=None)

    return parser


def resolve_replicates(args):
    """
    Return a list of (fold_tag, train_path, test_path, choose_train, choose_test)
    tuples to run, given the CLI args and dataset_paths' registry.
    """
    kind = dp.dataset_kind(args.dataset)

    if kind == "simple":
        train_path, test_path = dp.resolve_simple(args.dataset, args.data_dir)
        return [(None, train_path, test_path, None, None)]

    if kind == "crossval":
        seq_path, mat_path = dp.resolve_crossval_files(args.dataset, args.data_dir, args.crossval_fold_path)
        n_folds = args.k_folds or dp.count_crossval_folds(mat_path)
        fold_indices = [args.fold] if args.fold is not None else list(range(n_folds))
        replicates = []
        for fold_index in fold_indices:
            train_idx, test_idx = dp.load_crossval_indices(mat_path, fold_index)
            replicates.append((fold_index, seq_path, seq_path, train_idx, test_idx))
        return replicates

    if kind == "simulated":
        if args.simulated_type is None:
            raise SystemExit(f"--simulated-type is required for simulated dataset {args.dataset!r} "
                              f"(choose one of {dp.SIMULATED_TYPES}).")
        n_replicates = args.k_folds or dp.count_simulated_replicates(args.dataset, args.data_dir, args.simulated_type)
        fold_indices = [args.fold] if args.fold is not None else list(range(n_replicates))
        replicates = []
        for fold_index in fold_indices:
            train_path, test_path = dp.resolve_simulated_files(args.dataset, args.data_dir, args.simulated_type, fold_index)
            replicates.append((fold_index, train_path, test_path, None, None))
        return replicates

    raise AssertionError(f"Unhandled dataset kind {kind!r}")


def build_config(args):
    """Build a finetuning-style config Namespace, reusing barcodebert's own parser for all defaults."""
    parser = get_parser()
    config = parser.parse_args(["--pretrained-checkpoint", args.pretrained_checkpoint, "--dataset", args.dataset])

    config.data_dir = args.data_dir
    config.epochs = args.epochs
    config.batch_size_per_gpu = args.batch_size_per_gpu
    config.lr_relative = args.lr_relative
    config.weight_decay = args.weight_decay
    config.optimizer = args.optimizer
    config.scheduler = args.scheduler
    config.freeze_encoder = args.freeze_encoder
    config.skip_validation = args.skip_validation
    config.models_dir = args.output_dir
    config.run_name = args.run_name
    config.save_best_model = not args.no_save_best_model
    config.log_wandb = args.log_wandb
    config.disable_wandb = not args.log_wandb
    config.wandb_entity = args.wandb_entity
    config.wandb_project = args.wandb_project
    config.log_interval = args.log_interval
    config.print_interval = None
    config.seed = args.seed
    config.no_cuda = args.no_cuda
    config.cpu_workers = args.cpu_workers
    config.checkpoint_path = ""
    config.checkpoint_path_resume = ""

    # Single-process training only (no torchrun/DDP): this script is meant to
    # make ad hoc fine-tuning easy on one machine. For multi-GPU/distributed
    # training, use BarcodeMAE/barcodebert/finetuning.py directly.
    config.world_size = 1
    config.distributed = False
    config.global_rank = 0
    config.local_rank = None
    config.batch_size = config.batch_size_per_gpu * config.world_size

    if config.seed is not None:
        utils.set_rng_seeds_fixed(config.seed, all_gpu=torch.cuda.is_available())
    if config.cpu_workers is None:
        config.cpu_workers = utils.get_num_cpu_available()
    if config.run_name is None:
        config.run_name = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    config.run_id = utils.generate_id()

    return config


def load_encoder_and_sync_config(config, device):
    """
    Load the pretrained encoder, and copy over the architecture/tokenization
    settings it was pretrained with (k_mer, n_layers, ...), exactly like
    barcodebert.finetuning.run() does - so a fine-tuning run always uses a
    configuration compatible with the checkpoint it starts from.
    """
    pre_model, pre_checkpoint = load_pretrained_model(config.pretrained_checkpoint_path, device=device)
    pre_model.classifier = nn.Identity()

    keys_to_reuse = [
        "arch",  # NOTE: not part of the upstream keys_to_reuse list; needed so the checkpoint we
        # save records the *actual* encoder class (e.g. "maelm"), not argparse's "transformer"
        # default - otherwise evaluate.py cannot tell which model class to reconstruct.
        "k_mer",
        "stride",
        "max_len",
        "tokenizer",
        "bpe_path",
        "tokenize_n_nucleotide",
        "predict_n_nucleotide",
        "pretrain_levenshtein",
        "levenshtein_vectorized",
        "n_layers",
        "n_heads",
    ]
    default_kwargs = vars(get_parser().parse_args(["--pretrained_checkpoint=dummy.pt", "--dataset=foo_bar"]))
    for key in keys_to_reuse:
        if not hasattr(config, key) or getattr(config, key) == getattr(pre_checkpoint["config"], key):
            pass
        elif getattr(config, key) is None or getattr(config, key) == default_kwargs[key]:
            print(
                f"  Using {key}={getattr(pre_checkpoint['config'], key)} from the pretrained checkpoint "
                f"(overriding default {getattr(config, key)})."
            )
        else:
            raise ValueError(
                f"config value for {key} differs from pretrained checkpoint:"
                f" {getattr(config, key)} (ours) vs {getattr(pre_checkpoint['config'], key)} (pretrained checkpoint)"
            )
        setattr(config, key, getattr(pre_checkpoint["config"], key, None))

    return pre_model, pre_checkpoint


def run_one_replicate(config, device, train_path, test_path, choose_train, choose_test, fold_tag, use_wandb):
    print("\n" + "=" * 88)
    tag_str = "single run" if fold_tag is None else f"fold/replicate {fold_tag}"
    print(f"Dataset {config.dataset_name!r} ({tag_str})")
    print(f"  train: {train_path}")
    print(f"  test:  {test_path}")

    pre_model, pre_checkpoint = load_encoder_and_sync_config(config, device)

    if config.stride is None:
        config.stride = config.k_mer

    dataset_args = {
        "k_mer": config.k_mer,
        "stride": config.stride,
        "tokenizer": config.tokenizer,
        "bpe_path": config.bpe_path,
        "tokenize_n_nucleotide": config.tokenize_n_nucleotide,
        "dataset_format": config.dataset_name,
    }
    dataset_train = DNADataset(
        file_path=train_path,
        randomize_offset=True,
        choose_indexes_set=choose_train,
        max_len=0,
        **dataset_args,
        label_set=None,
    )
    dataset_test = DNADataset(
        file_path=test_path,
        randomize_offset=False,
        choose_indexes_set=choose_test,
        max_len=dataset_train.max_len,
        **dataset_args,
        label_set=dataset_train.label_set,
    )

    dl_train_kwargs = {"batch_size": config.batch_size_per_gpu, "drop_last": True, "shuffle": True, "worker_init_fn": utils.worker_seed_fn}
    dl_test_kwargs = {"batch_size": config.batch_size_per_gpu, "drop_last": False, "shuffle": False, "worker_init_fn": utils.worker_seed_fn}
    use_cuda = not config.no_cuda and torch.cuda.is_available()
    if use_cuda:
        dl_train_kwargs.update(num_workers=config.cpu_workers, pin_memory=True)
        dl_test_kwargs.update(num_workers=config.cpu_workers, pin_memory=True)

    dataloader_train = torch.utils.data.DataLoader(dataset_train, **dl_train_kwargs)
    dataloader_test = torch.utils.data.DataLoader(dataset_test, **dl_test_kwargs)

    model = ClassificationModel(pre_model, dataset_train.num_labels).to(device)
    if config.freeze_encoder:
        for param in model.base_model.parameters():
            param.requires_grad = False

    config.lr = config.lr_relative * config.batch_size / BASE_BATCH_SIZE
    params = model.classifier.parameters() if config.freeze_encoder else model.parameters()
    optimizer = getattr(torch.optim, config.optimizer)(params, lr=config.lr, weight_decay=config.weight_decay)
    if config.scheduler.lower() != "onecycle":
        raise NotImplementedError(f"Scheduler {config.scheduler} not supported.")
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, [p["lr"] for p in optimizer.param_groups], epochs=config.epochs, steps_per_epoch=len(dataloader_train)
    )
    criterion = nn.CrossEntropyLoss()

    suffix = "" if fold_tag is None else f"_{fold_tag:02d}"
    run_dir = os.path.join(config.models_dir, config.dataset_name, config.run_name)
    checkpoint_path = os.path.join(run_dir, f"checkpoint_finetune{suffix}.pt")
    best_checkpoint_path = os.path.join(run_dir, f"best_finetune{suffix}.pt")

    if use_wandb:
        import wandb

        wandb.init(
            entity=config.wandb_entity,
            project=config.wandb_project,
            name=f"{config.run_name}{suffix}",
            group=config.run_name,
            job_type="linearprobe" if config.freeze_encoder else "finetune",
            config={k: v for k, v in vars(config).items() if isinstance(v, (int, float, str, bool, type(None)))},
        )

    total_step = 0
    n_samples_seen = 0
    best_stats = {"max_accuracy": 0.0, "best_epoch": 0}
    for epoch in range(1, config.epochs + 1):
        t0 = time.time()
        train_stats, total_step, n_samples_seen = train_one_epoch(
            config=config,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            criterion=criterion,
            dataloader=dataloader_train,
            device=device,
            epoch=epoch,
            n_epoch=config.epochs,
            total_step=total_step,
            n_samples_seen=n_samples_seen,
        )
        print(
            f"Epoch {epoch:3d}/{config.epochs}  train loss {train_stats['loss']:.5f}"
            f"  train acc {train_stats['accuracy']:.2f}%  ({time.time() - t0:.1f}s)"
        )

        if not config.skip_validation:
            eval_stats = evaluate(dataloader=dataloader_test, model=model, device=device, partition_name="Test", verbosity=0)
            if eval_stats["accuracy"] >= best_stats["max_accuracy"]:
                best_stats["max_accuracy"] = eval_stats["accuracy"]
                best_stats["best_epoch"] = epoch
            print(f"           test  loss {eval_stats['cross-entropy']:.5f}  test  acc {eval_stats['accuracy']:.2f}%")
            if use_wandb:
                import wandb

                wandb.log({**{f"train/{k}": v for k, v in train_stats.items()}, **{f"test/{k}": v for k, v in eval_stats.items()}}, step=epoch)

        os.makedirs(run_dir, exist_ok=True)
        safe_save_model(
            {"model": model, "optimizer": optimizer, "scheduler": scheduler},
            checkpoint_path,
            config=config,
            epoch=epoch,
            total_step=total_step,
            n_samples_seen=n_samples_seen,
            bert_config=pre_checkpoint["bert_config"],
            **best_stats,
        )
        if config.save_best_model and best_stats["best_epoch"] == epoch:
            import shutil

            shutil.copyfile(checkpoint_path, best_checkpoint_path)

    print(f"\nFinal evaluation for {tag_str}:")
    final_test_stats = evaluate(dataloader=dataloader_test, model=model, device=device, partition_name="Test")
    final_train_stats = evaluate(dataloader=dataloader_train, model=model, device=device, partition_name="Train")
    if use_wandb:
        import wandb

        wandb.log({**{f"final_test/{k}": v for k, v in final_test_stats.items()}, **{f"final_train/{k}": v for k, v in final_train_stats.items()}})
        wandb.finish()

    return final_train_stats, final_test_stats


def summarize(label, results):
    if not results:
        return
    print(f"\n{label} (mean over {len(results)} run(s)):")
    keys = results[0].keys()
    for key in keys:
        values = [r[key] for r in results]
        mean = float(np.mean(values))
        if len(values) > 1:
            print(f"  {key:<20s} {mean:8.3f}  (std {float(np.std(values)):.3f}, n={len(values)})")
        else:
            print(f"  {key:<20s} {mean:8.3f}")


def main():
    parser = build_arg_parser()
    args = parser.parse_args()

    if args.list_datasets:
        print(dp.describe())
        return

    if not args.dataset:
        parser.error("--dataset is required (use --list-datasets to see the available options).")
    if not args.pretrained_checkpoint:
        parser.error("--pretrained-checkpoint is required.")

    replicates = resolve_replicates(args)
    config = build_config(args)
    device = torch.device("cuda" if (not config.no_cuda and torch.cuda.is_available()) else "cpu")
    print(f"Using device {device}")

    all_train_results, all_test_results = [], []
    for fold_tag, train_path, test_path, choose_train, choose_test in replicates:
        train_stats, test_stats = run_one_replicate(
            config, device, train_path, test_path, choose_train, choose_test, fold_tag, use_wandb=config.log_wandb
        )
        all_train_results.append(train_stats)
        all_test_results.append(test_stats)

    summarize("Train results", all_train_results)
    summarize("Test results", all_test_results)


if __name__ == "__main__":
    main()
