#!/usr/bin/env python
"""
Evaluate a checkpoint produced by train.py (or by BarcodeMAE's own
barcodebert/finetuning.py) on the test split of any dataset supported by
barcodebert.datasets.DNADataset.

The checkpoint is self-contained: it stores its own encoder architecture
(bert_config) and training config, so only the checkpoint file and the
dataset's raw FASTA files are needed - the original pretrained-checkpoint
file used to *start* fine-tuning is not required here.

See README.md in this directory for usage examples, or run:
    python evaluate.py --list-datasets
"""

import argparse
import os
import sys

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_BARCODEMAE_ROOT = os.environ.get("BARCODEMAE_ROOT") or os.path.normpath(os.path.join(_HERE, "..", "BarcodeMAE"))
if _BARCODEMAE_ROOT not in sys.path:
    sys.path.insert(0, _BARCODEMAE_ROOT)
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import dataset_paths as dp  # noqa: E402
from train import resolve_replicates  # noqa: E402  (reuse the same fold/replicate resolution as train.py)

from barcodebert.datasets import DNADataset  # noqa: E402
from barcodebert.evaluation import evaluate  # noqa: E402
from barcodebert.finetuning import ClassificationModel  # noqa: E402
from barcodebert.utils import remove_extra_pre_fix  # noqa: E402
from transformers import BertConfig, BertForTokenClassification, BertModel  # noqa: E402


def build_arg_parser():
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--list-datasets", action="store_true", help="Print all supported datasets and exit.")

    g = parser.add_argument_group("Data")
    g.add_argument("--dataset", type=str, help="Dataset name. See --list-datasets.")
    g.add_argument(
        "--data-dir",
        type=str,
        default="/home/velazquez/dna_foundation/clean_code/data",
        help="Root directory containing the dataset FASTA/mat files (same value used for training).",
    )
    g.add_argument("--simulated-type", type=str, choices=dp.SIMULATED_TYPES, default=None)
    g.add_argument("--crossval-fold", dest="crossval_fold_path", type=str, default=None)
    g.add_argument("--k-folds", type=int, default=None)
    g.add_argument("--fold", type=int, default=None, help="Evaluate only this single fold/replicate index.")

    g = parser.add_argument_group("Checkpoint")
    g.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="Path to a single fine-tuned checkpoint to evaluate (only valid together with --fold, or "
        "for a simple-split dataset that has no folds).",
    )
    g.add_argument(
        "--checkpoint-dir",
        type=str,
        default="model_checkpoints",
        help="Root directory to look up checkpoints in, using the same layout train.py writes: "
        "<checkpoint-dir>/<dataset>/<run-name>/{checkpoint,best}_finetune[_<fold>].pt",
    )
    g.add_argument("--run-name", type=str, default=None, help="Run name used when training (see the training log/output dir).")
    g.add_argument("--which", type=str, choices=["best", "last"], default="best", help="Which per-fold checkpoint to evaluate.")

    g = parser.add_argument_group("Evaluation")
    g.add_argument("--batch-size", type=int, default=32)
    g.add_argument("--also-eval-train", action="store_true", help="Also report metrics on the training split.")
    g.add_argument("--no-cuda", action="store_true")

    return parser


def resolve_checkpoint_path(args, fold_tag):
    if args.checkpoint is not None:
        return args.checkpoint
    if not args.run_name:
        raise SystemExit("--run-name is required when using --checkpoint-dir (or pass --checkpoint directly).")
    suffix = "" if fold_tag is None else f"_{fold_tag:02d}"
    filename = f"{'best' if args.which == 'best' else 'checkpoint'}_finetune{suffix}.pt"
    return os.path.join(args.checkpoint_dir, args.dataset, args.run_name, filename)


def load_finetuned_model(checkpoint_path, num_labels, device):
    ckpt = torch.load(checkpoint_path, map_location=device)
    bert_config = BertConfig(**ckpt["bert_config"])
    arch = ckpt["config"].arch
    if arch == "maelm":
        base_model = BertModel(bert_config)
    elif arch == "transformer":
        base_model = BertForTokenClassification(bert_config)
    else:
        raise ValueError(f"Unrecognized arch {arch!r} in checkpoint {checkpoint_path}.")
    model = ClassificationModel(base_model, num_labels)
    model.load_state_dict(remove_extra_pre_fix(ckpt["model"]))
    model.to(device)
    model.eval()
    return model, ckpt["config"]


def evaluate_one_replicate(args, device, train_path, test_path, choose_train, choose_test, fold_tag):
    checkpoint_path = resolve_checkpoint_path(args, fold_tag)
    if not os.path.isfile(checkpoint_path):
        print(f"  [skip] checkpoint not found: {checkpoint_path}")
        return None

    saved_config = torch.load(checkpoint_path, map_location="cpu")["config"]
    dataset_args = {
        "k_mer": saved_config.k_mer,
        "stride": saved_config.stride,
        "tokenizer": saved_config.tokenizer,
        "bpe_path": saved_config.bpe_path,
        "tokenize_n_nucleotide": saved_config.tokenize_n_nucleotide,
        "dataset_format": args.dataset,
    }

    # The training split (with the label_set it induces) must be rebuilt first:
    # the test split's labels are only meaningful relative to that same mapping.
    dataset_train = DNADataset(
        file_path=train_path, randomize_offset=False, choose_indexes_set=choose_train, max_len=0, **dataset_args, label_set=None
    )
    dataset_test = DNADataset(
        file_path=test_path,
        randomize_offset=False,
        choose_indexes_set=choose_test,
        max_len=dataset_train.max_len,
        **dataset_args,
        label_set=dataset_train.label_set,
    )

    model, _ = load_finetuned_model(checkpoint_path, dataset_train.num_labels, device)

    tag_str = "single run" if fold_tag is None else f"fold/replicate {fold_tag}"
    print(f"\n{'=' * 88}\nDataset {args.dataset!r} ({tag_str})  checkpoint: {checkpoint_path}")

    dl_kwargs = {"batch_size": args.batch_size, "drop_last": False, "shuffle": False}
    dataloader_test = torch.utils.data.DataLoader(dataset_test, **dl_kwargs)
    result = {"test": evaluate(dataloader=dataloader_test, model=model, device=device, partition_name="Test")}

    if args.also_eval_train:
        dataloader_train = torch.utils.data.DataLoader(dataset_train, **dl_kwargs)
        result["train"] = evaluate(dataloader=dataloader_train, model=model, device=device, partition_name="Train")

    return result


def summarize(label, results):
    if not results:
        return
    print(f"\n{label} (mean over {len(results)} run(s)):")
    for key in results[0].keys():
        values = [r[key] for r in results]
        mean = float(np.mean(values))
        if len(values) > 1:
            print(f"  {key:<20s} {mean:8.3f}  (std {float(np.std(values)):.3f}, n={len(values)})")
        else:
            print(f"  {key:<20s} {mean:8.3f}")


def main():
    parser = build_arg_parser()
    args = parser.parse_args()

    if args.list_datasets:
        print(dp.describe())
        return
    if not args.dataset:
        parser.error("--dataset is required (use --list-datasets to see the available options).")

    replicates = resolve_replicates(args)
    if args.checkpoint is not None and len(replicates) > 1:
        parser.error("--checkpoint refers to a single file; pass --fold to select one replicate, or use --checkpoint-dir + --run-name instead.")

    device = torch.device("cuda" if (not args.no_cuda and torch.cuda.is_available()) else "cpu")
    print(f"Using device {device}")

    all_test_results, all_train_results = [], []
    for fold_tag, train_path, test_path, choose_train, choose_test in replicates:
        result = evaluate_one_replicate(args, device, train_path, test_path, choose_train, choose_test, fold_tag)
        if result is None:
            continue
        all_test_results.append(result["test"])
        if "train" in result:
            all_train_results.append(result["train"])

    summarize("Test results", all_test_results)
    if args.also_eval_train:
        summarize("Train results", all_train_results)


if __name__ == "__main__":
    main()
