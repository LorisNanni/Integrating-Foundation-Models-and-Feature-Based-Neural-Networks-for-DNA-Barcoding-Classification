"""
Dataset path resolution for the FASTA-based finetuning datasets supported by
``barcodebert.datasets.DNADataset`` (see BarcodeMAE/barcodebert/datasets.py).

``BarcodeMAE/barcodebert/finetuning.py`` hardcodes a per-dataset file lookup
directly inside its ``run()`` function, and that lookup has two gaps
relative to what ``DNADataset`` actually understands:

* ``Drosophila`` is looked up as ``Drosophilatrain.fas``/``Drosophilatest.fas``
  (lower-case "train"/"test"), while every other "simple split" dataset -
  and the actual files shipped in the data directory - use
  ``DrosophilaTrain.fas``/``DrosophilaTest.fas`` (capitalised, like
  ``birdsTrain.fas``, ``batsTest.fas``, etc). On a case-sensitive filesystem
  this means the original script cannot find the Drosophila files at all.
* ``unseen_insect_dataset`` is a valid ``dataset_format`` for ``DNADataset``
  (handled the same way as ``insect_dataset_species``/``_genus``) but is
  missing from the allow-list ``finetuning.run`` checks against, so it can
  never be reached from that CLI.

This module gives every ``dataset_format`` value ``DNADataset`` supports a
single, consistent resolution rule (fixing both gaps above), used by both
train.py and evaluate.py in this directory.
"""

import glob
import os

# Datasets that ship as a single Train/Test FASTA pair named
# "<dataset>Train.fas" / "<dataset>Test.fas", both directly under --data-dir.
SIMPLE_SPLIT_DATASETS = [
    "fishes",
    "birds",
    "bats",
    "Cypraeidae",
    "Drosophila",
    "Inga",
    "insect_dataset_species",
    "insect_dataset_genus",
    "unseen_insect_dataset",
    "fish_12S",
    "fish_12S_Noise",
]

# Datasets with their own train/test layout under a subdirectory of --data-dir.
SPECIAL_SPLIT_DATASETS = {
    "unseen": ("CanadianInvertebrates-ML/supervised_train.fas", "CanadianInvertebrates-ML/unseen.fas"),
    "myco_genus": ("MycoAI/trainset.fasta", "MycoAI/test1.fasta"),
    "myco_species": ("MycoAI/trainset.fasta", "MycoAI/test1.fasta"),
}

# Datasets evaluated with k-fold cross-validation over a single FASTA file,
# using train/test indices stored in a MATLAB .mat file (data/splitBeetle.mat,
# data/splitFish.mat: each holds a 1xK cell array "trainPattern"/"testPattern").
CROSSVAL_DATASETS = {
    "beetle": {"sequences": "beetle-seq.fas", "default_mat": "splitBeetle.mat"},
    "fish": {"sequences": "fish-seq.fas", "default_mat": "splitFish.mat"},
}

# Simulated datasets: --dataset is the base name (GNe1000, GNe10000, GNe50000),
# and --simulated-type picks Filtered/Unfiltered. Each combination ships 100
# train/test replicate pairs, indexed 0..99, under
# SimulatedDATA/forBLOG/<type>/Simulated/<name>/<name>r<i>_{train,test}.fasta
SIMULATED_PREFIX = "GNe"
SIMULATED_TYPES = ("Filtered", "Unfiltered")

ALL_SIMPLE_DATASET_NAMES = sorted(set(SIMPLE_SPLIT_DATASETS) | set(SPECIAL_SPLIT_DATASETS))
ALL_CROSSVAL_DATASET_NAMES = sorted(CROSSVAL_DATASETS)


def dataset_kind(dataset_name):
    """Return one of "simple", "crossval", "simulated" for a --dataset value."""
    if dataset_name in CROSSVAL_DATASETS:
        return "crossval"
    if dataset_name.startswith(SIMULATED_PREFIX):
        return "simulated"
    if dataset_name in SIMPLE_SPLIT_DATASETS or dataset_name in SPECIAL_SPLIT_DATASETS:
        return "simple"
    raise ValueError(
        f"Unrecognized dataset {dataset_name!r}. Known datasets: {ALL_SIMPLE_DATASET_NAMES} and "
        f"{ALL_CROSSVAL_DATASET_NAMES} (k-fold), plus any {SIMULATED_PREFIX}<size> simulated dataset "
        f"(e.g. GNe1000, GNe10000, GNe50000) combined with --simulated-type."
    )


def resolve_simple(dataset_name, data_dir):
    """Return (train_path, test_path) for a "simple" or "special" split dataset."""
    if dataset_name in SPECIAL_SPLIT_DATASETS:
        train_rel, test_rel = SPECIAL_SPLIT_DATASETS[dataset_name]
    else:
        train_rel, test_rel = f"{dataset_name}Train.fas", f"{dataset_name}Test.fas"
    return os.path.join(data_dir, train_rel), os.path.join(data_dir, test_rel)


def resolve_crossval_files(dataset_name, data_dir, mat_path=None):
    """Return (sequences_path, mat_path) for a k-fold cross-validation dataset."""
    spec = CROSSVAL_DATASETS[dataset_name]
    sequences_path = os.path.join(data_dir, spec["sequences"])
    if mat_path is None:
        mat_path = os.path.join(data_dir, spec["default_mat"])
    return sequences_path, mat_path


def load_crossval_indices(mat_path, fold_index):
    """Return (train_indices, test_indices) as sets of int, for one fold."""
    import scipy.io

    mat = scipy.io.loadmat(mat_path)
    train_idx = mat["trainPattern"][0][fold_index][0]
    test_idx = mat["testPattern"][0][fold_index][0]
    return set(int(i) for i in train_idx), set(int(i) for i in test_idx)


def count_crossval_folds(mat_path):
    import scipy.io

    mat = scipy.io.loadmat(mat_path)
    return mat["trainPattern"].shape[1]


def resolve_simulated_files(dataset_name, data_dir, simulated_type, fold_index):
    """Return (train_path, test_path) for one replicate of a simulated (GNe*) dataset."""
    if simulated_type not in SIMULATED_TYPES:
        raise ValueError(f"--simulated-type must be one of {SIMULATED_TYPES}, got {simulated_type!r}.")
    base = os.path.join(data_dir, "SimulatedDATA", "forBLOG", simulated_type, "Simulated", dataset_name)
    train_path = os.path.join(base, f"{dataset_name}r{fold_index}_train.fasta")
    test_path = os.path.join(base, f"{dataset_name}r{fold_index}_test.fasta")
    return train_path, test_path


def count_simulated_replicates(dataset_name, data_dir, simulated_type):
    base = os.path.join(data_dir, "SimulatedDATA", "forBLOG", simulated_type, "Simulated", dataset_name)
    return len(glob.glob(os.path.join(base, f"{dataset_name}r*_train.fasta")))


def describe():
    """Human-readable summary of all supported datasets, for --list-datasets / the README."""
    lines = []
    lines.append("Simple train/test split datasets (--dataset <name>):")
    for name in ALL_SIMPLE_DATASET_NAMES:
        if name in SPECIAL_SPLIT_DATASETS:
            train_rel, test_rel = SPECIAL_SPLIT_DATASETS[name]
        else:
            train_rel, test_rel = f"{name}Train.fas", f"{name}Test.fas"
        lines.append(f"  {name:<24s} {train_rel}  /  {test_rel}")
    lines.append("")
    lines.append("K-fold cross-validation datasets (--dataset <name> --k-folds 10):")
    for name, spec in CROSSVAL_DATASETS.items():
        lines.append(f"  {name:<24s} {spec['sequences']}  (folds from {spec['default_mat']})")
    lines.append("")
    lines.append(
        "Simulated datasets (--dataset GNe<size> --simulated-type {Filtered,Unfiltered}), "
        "e.g. --dataset GNe1000, GNe10000, GNe50000:"
    )
    lines.append("  SimulatedDATA/forBLOG/<type>/Simulated/<name>/<name>r<0..99>_{train,test}.fasta")
    return "\n".join(lines)
