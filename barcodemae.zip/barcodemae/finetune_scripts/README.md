# BarcodeMAE fine-tuning, evaluation & feature extraction

Companion CLI tools for [BarcodeMAE](https://github.com/bioscan-ml/BarcodeMAE), built for
*"Integrating Foundation Models and Feature-Based Neural Networks for DNA Barcoding
Classification"* (Nanni, Fusaro, Carraro & Brahnam - see [Citation](#citation)).

BarcodeMAE ships a pretraining script and a fine-tuning script that only understand two
hard-coded dataset formats (`CANADA-1.5M`, `BIOSCAN-5M`). For the paper above, its dataloader
was extended to read plain FASTA files, which lets the same pretrained encoder be fine-tuned,
evaluated, and used as a feature extractor on many additional barcode datasets: fixed-split
benchmarks (birds, fishes, bats, ...), k-fold cross-validation datasets (beetle, fish), and
simulated noise-robustness datasets (`GNe*`).

This repository adds three dataset-aware CLIs on top of that extended dataloader:

| Script | Purpose |
| --- | --- |
| [`train.py`](train.py) | Fine-tune a pretrained checkpoint on any supported dataset (simple split, k-fold CV, or simulated). |
| [`evaluate.py`](evaluate.py) | Re-score a fine-tuned checkpoint on the test split, without retraining. |
| [`extract_features.py`](extract_features.py) | Use any checkpoint (pretrained or fine-tuned) purely as a feature extractor and dump embeddings to a plain-text matrix. |

They are thin wrappers: the model, the training step and the evaluation metrics all come
from BarcodeMAE's own `barcodebert` package, unmodified. [`dataset_paths.py`](dataset_paths.py)
supplies the one piece that was missing - a complete, consistent dataset → file-path registry
(the two gaps in the original per-dataset lookup are documented in
[Notes](#notes-on-the-upstream-codebase) below).

## Repository layout

These scripts expect a checkout of BarcodeMAE as a sibling directory:

```
<root>/
├── BarcodeMAE/              # https://github.com/bioscan-ml/BarcodeMAE
│   └── barcodebert/         # imported as a library, never modified
└── finetune_scripts/        # this directory
    ├── dataset_paths.py
    ├── train.py
    ├── evaluate.py
    └── extract_features.py
```

If your checkout lives elsewhere, point `BARCODEMAE_ROOT` at it instead of relying on the
default relative path:

```shell
export BARCODEMAE_ROOT=/path/to/BarcodeMAE
```

## Installation

This directory ships alongside `BarcodeMAE/` in the same repository, so cloning the repository
gets you both:

```shell
pip install -r BarcodeMAE/requirements.txt
pip install biopython scipy   # FASTA parsing + .mat cross-validation folds
```

(If you copy this directory elsewhere, point `BARCODEMAE_ROOT` at wherever your `BarcodeMAE/`
checkout lives instead, as described above.)

You'll also need a pretrained BarcodeMAE (or BarcodeBERT) checkpoint - see the
[BarcodeMAE README](https://github.com/bioscan-ml/BarcodeMAE#readme) for pretraining
instructions, or use a released checkpoint if one is available.

## Data layout

Point `--data-dir` at a directory containing your FASTA files. Run `--list-datasets` on any
of the three scripts to see exactly which file(s) each `--dataset` name resolves to:

```shell
$ python train.py --list-datasets
Simple train/test split datasets (--dataset <name>):
  Cypraeidae               CypraeidaeTrain.fas  /  CypraeidaeTest.fas
  Drosophila               DrosophilaTrain.fas  /  DrosophilaTest.fas
  Inga                     IngaTrain.fas  /  IngaTest.fas
  bats                     batsTrain.fas  /  batsTest.fas
  birds                    birdsTrain.fas  /  birdsTest.fas
  fish_12S                 fish_12STrain.fas  /  fish_12STest.fas
  fish_12S_Noise           fish_12S_NoiseTrain.fas  /  fish_12S_NoiseTest.fas
  fishes                   fishesTrain.fas  /  fishesTest.fas
  insect_dataset_genus     insect_dataset_genusTrain.fas  /  insect_dataset_genusTest.fas
  insect_dataset_species   insect_dataset_speciesTrain.fas  /  insect_dataset_speciesTest.fas
  myco_genus               MycoAI/trainset.fasta  /  MycoAI/test1.fasta
  myco_species             MycoAI/trainset.fasta  /  MycoAI/test1.fasta
  unseen                   CanadianInvertebrates-ML/supervised_train.fas  /  CanadianInvertebrates-ML/unseen.fas
  unseen_insect_dataset    unseen_insect_datasetTrain.fas  /  unseen_insect_datasetTest.fas

K-fold cross-validation datasets (--dataset <name> --k-folds 10):
  beetle                   beetle-seq.fas  (folds from splitBeetle.mat)
  fish                     fish-seq.fas  (folds from splitFish.mat)

Simulated datasets (--dataset GNe<size> --simulated-type {Filtered,Unfiltered}):
  SimulatedDATA/forBLOG/<type>/Simulated/<name>/<name>r<0..99>_{train,test}.fasta
```

A dataset is listed as soon as `barcodebert.datasets.DNADataset` supports its format, even if
you don't have the matching files locally - add them under `--data-dir` following the
convention shown above and it will work with no code changes.

## Training

```shell
python train.py \
  --dataset birds \
  --data-dir /path/to/data \
  --pretrained-checkpoint /path/to/best_pretraining.pt \
  --epochs 150 \
  --run-name birds_run1
```

Checkpoints are written to `<output-dir>/<dataset>/<run-name>/checkpoint_finetune.pt` (every
epoch, overwritten) and `.../best_finetune.pt` (copied whenever test accuracy improves);
`--output-dir` defaults to `model_checkpoints`.

<details>
<summary><strong>Linear probing (frozen encoder)</strong></summary>

```shell
python train.py --dataset bats --data-dir /path/to/data \
  --pretrained-checkpoint /path/to/best_pretraining.pt \
  --freeze-encoder --run-name bats_linprobe
```
</details>

<details>
<summary><strong>K-fold cross-validation (beetle, fish)</strong></summary>

Runs all 10 folds (from `splitBeetle.mat`/`splitFish.mat`) by default and reports mean ± std
over folds; checkpoints are saved per-fold as `checkpoint_finetune_00.pt` …
`checkpoint_finetune_09.pt` (and `best_finetune_00.pt`, ...):

```shell
python train.py --dataset beetle --data-dir /path/to/data \
  --pretrained-checkpoint /path/to/best_pretraining.pt --run-name beetle_cv
```

Run a single fold only (e.g. for a cluster array job) with `--fold`:

```shell
python train.py --dataset fish --data-dir /path/to/data \
  --pretrained-checkpoint /path/to/best_pretraining.pt --fold 3 --run-name fish_cv
```
</details>

<details>
<summary><strong>Simulated noise-robustness datasets</strong></summary>

`--dataset` is the base name (`GNe1000`, `GNe10000`, `GNe50000`), `--simulated-type` picks
`Filtered` or `Unfiltered`. By default all 100 replicates are run and aggregated; use
`--fold` to run just one:

```shell
python train.py --dataset GNe1000 --simulated-type Filtered --data-dir /path/to/data \
  --pretrained-checkpoint /path/to/best_pretraining.pt --run-name gne1000_filtered
```
</details>

Other useful flags: `--epochs`, `--batch-size-per-gpu`, `--lr`, `--weight-decay`,
`--optimizer`, `--scheduler`, `--seed`, `--no-cuda`, `--cpu-workers`, `--skip-validation`
(skip the per-epoch test-set pass, only evaluate at the very end), `--log-wandb` (+
`--wandb-entity`/`--wandb-project`).

`k_mer`, `stride`, `tokenizer`, `n_layers`, `n_heads`, etc. are **not** exposed as flags:
they are always read from the pretrained checkpoint, so fine-tuning is guaranteed to use a
configuration compatible with the encoder it starts from.

> This script trains on a single process/GPU. For multi-GPU/distributed training with the
> full `torchrun` + Weights & Biases machinery, use `BarcodeMAE/barcodebert/finetuning.py`
> directly; this one targets the common "fine-tune on one dataset on one GPU" case.

## Evaluation

`evaluate.py` re-scores a checkpoint written by `train.py` (or by
`barcodebert/finetuning.py`) on the test split, without retraining. It only needs the
checkpoint - it stores its own encoder architecture and tokenization settings - plus the
same `--dataset`/`--data-dir` (and `--fold`/`--simulated-type` for CV/simulated datasets)
used at training time, so it can rebuild the exact train/test split and label mapping.

```shell
# Same --output-dir/--run-name layout train.py wrote to:
python evaluate.py --dataset birds --data-dir /path/to/data \
  --checkpoint-dir model_checkpoints --run-name birds_run1

# A specific k-fold checkpoint:
python evaluate.py --dataset beetle --data-dir /path/to/data \
  --checkpoint-dir model_checkpoints --run-name beetle_cv --fold 3

# All folds of a k-fold/simulated run at once (mean +/- std over folds):
python evaluate.py --dataset beetle --data-dir /path/to/data \
  --checkpoint-dir model_checkpoints --run-name beetle_cv

# Or point directly at one checkpoint file:
python evaluate.py --dataset bats --data-dir /path/to/data \
  --checkpoint model_checkpoints/bats/bats_linprobe/best_finetune.pt

# Also report train-split metrics, and evaluate the last epoch instead of the best one:
python evaluate.py --dataset birds --data-dir /path/to/data \
  --checkpoint-dir model_checkpoints --run-name birds_run1 --also-eval-train --which last
```

## Feature extraction only

If you just want BarcodeMAE's embeddings - e.g. to feed into another classifier, as in the
paper's ensemble - without fine-tuning or evaluating anything, use `extract_features.py`. It
loads **any** checkpoint (a raw pretrained one, or a fine-tuned one from `train.py`), runs it
over a set of barcodes, and writes one feature vector per row to a plain-text file with
`numpy.savetxt`. Each feature vector is the attention-mask-weighted mean of the encoder's last
hidden state over the non-padding tokens - the same pooling
`barcodebert.datasets.representations_from_df` uses for the project's existing
kNN/feature-based classifiers.

```shell
# Any FASTA file, any checkpoint - the encoder's k-mer/tokenizer settings are read from the
# checkpoint, so nothing else needs to be specified:
python extract_features.py \
  --checkpoint /path/to/best_pretraining.pt \
  --input path/to/any_barcodes.fasta \
  --output features.txt

# Or use the same --dataset registry as train.py/evaluate.py:
python extract_features.py --checkpoint /path/to/best_pretraining.pt \
  --dataset birds --data-dir /path/to/data --split test --output birds_test_features.txt

# A fine-tuned checkpoint works exactly the same way - its classification head is
# dropped automatically, only the encoder is used:
python extract_features.py --checkpoint model_checkpoints/birds/birds_run1/best_finetune.pt \
  --dataset birds --data-dir /path/to/data --output birds_features_finetuned.txt
```

`features.txt` has shape `(n_sequences, hidden_size)`, one row per input sequence in FASTA
order (for `--split all`, the default: train file rows first, then test file rows). Pass
`--save-ids ids.txt` to also write each row's FASTA header, one per line in the same order, if
you need to match feature vectors back to specific barcodes.

## Notes on the upstream codebase

While building these scripts we found and worked around two small gaps in
`BarcodeMAE/barcodebert/finetuning.py`'s own dataset lookup (documented in the comments at the
top of `dataset_paths.py`), plus one that only surfaces once a checkpoint is reloaded outside
of that script:

* It looks up Drosophila as `Drosophilatrain.fas`/`Drosophilatest.fas` (lower-case), while the
  actual files (and every sibling dataset) are named `DrosophilaTrain.fas`/`DrosophilaTest.fas`.
  `dataset_paths.py` uses the same `<name>Train.fas`/`<name>Test.fas` convention for every
  simple-split dataset, so this "just works" without a special case.
* `unseen_insect_dataset` is a format `DNADataset` understands but is missing from
  `finetuning.run()`'s allow-list, so it could never be reached from that CLI. It is included
  here like any other simple-split dataset.
* `finetuning.run()`'s own `keys_to_reuse` list (the settings copied from the pretrained
  checkpoint into the fine-tuning config) never copies `arch`, so a fine-tuned checkpoint's
  saved config always records argparse's `"transformer"` default instead of the encoder it was
  actually built from (e.g. `"maelm"`). This is harmless as long as nothing re-derives the
  model class from that saved config - but `evaluate.py`/`extract_features.py` need to do
  exactly that to reload a checkpoint standalone, so `train.py` copies `arch` too.

None of `BarcodeMAE/barcodebert/finetuning.py` or `datasets.py` were modified to fix these -
`train.py`/`evaluate.py`/`extract_features.py` resolve paths and configuration themselves
before calling into the shared, unmodified `DNADataset`/`ClassificationModel`/
`train_one_epoch`/`evaluate`/`load_pretrained_model`/`safe_save_model` code.

## License

Same as [BarcodeMAE](https://github.com/bioscan-ml/BarcodeMAE) (MIT).

## Citation

If you use these scripts, please cite the paper they were built for:

```latex
@article{nanni2026integrating,
  title   = {Integrating Foundation Models and Feature-Based Neural Networks for {DNA} Barcoding Classification},
  author  = {Nanni, Loris and Fusaro, Daniel and Carraro, Eddie and Brahnam, Sheryl},
  journal = {Computational Biology and Chemistry},
  year    = {2026},
  note    = {Manuscript submitted for publication},
}
```

Please also cite BarcodeMAE itself, whose pretrained encoder and dataloader these tools build on:

```latex
@article{safari2025barcodemae,
  title         = {Enhancing DNA Foundation Models to Address Masking Inefficiencies},
  author        = {Safari, Monireh and Millan Arias, Pablo and Lowe, Scott C. and Kari, Lila and Chang, Angel X. and Taylor, Graham W.},
  journal       = {arXiv preprint arXiv:2502.18405},
  year          = {2025},
  eprint        = {2502.18405},
  archivePrefix = {arXiv},
  primaryClass  = {cs.LG},
  doi           = {10.48550/arXiv.2502.18405},
}
```
