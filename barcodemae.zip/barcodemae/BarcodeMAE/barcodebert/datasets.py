"""
Datasets.
"""

import os
from itertools import product

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchtext.vocab import vocab as build_vocab_from_dict
from transformers import AutoTokenizer

from Bio import SeqIO

from typing import Tuple


class KmerTokenizer(object):
    def __init__(self, k, vocabulary_mapper, max_len, stride=1, padding=False):
        self.k = k
        self.stride = stride
        self.padding = padding
        self.max_len = max_len
        self.vocabulary_mapper = vocabulary_mapper

    def __call__(self, dna_sequence, offset=0) -> Tuple[list, list]:
        tokens = []
        att_mask = [1] * (self.max_len // self.stride)
        x = dna_sequence[offset:]
        if self.padding:
            if len(x) > self.max_len:
                x = x[: self.max_len]
            else:
                att_mask[len(x) // self.stride :] = [0] * (len(att_mask) - len(x) // self.stride)
                x = x + "N" * (self.max_len - len(x))
        for i in range(0, len(x) - self.k + 1, self.stride):
            k_mer = x[i : i + self.k]
            tokens.append(k_mer)

        tokens = torch.tensor(self.vocabulary_mapper(tokens), dtype=torch.int64)
        att_mask = torch.tensor(att_mask, dtype=torch.int32)

        return tokens, att_mask


class BPETokenizer(object):
    def __init__(self, padding=False, max_tokenized_len=128, bpe_path=None):
        self.padding = padding
        self.max_tokenized_len = max_tokenized_len

        assert os.path.isdir(bpe_path), f"The bpe path does not exist: {bpe_path}"

        self.bpe = AutoTokenizer.from_pretrained(bpe_path)

        # root_folder = os.path.dirname(__file__)
        # if bpe_type == "dnabert":
        #     # self.bpe = AutoTokenizer.from_pretrained("zhihan1996/DNABERT-2-117M", trust_remote_code=True)
        #     bpe_folder = os.path.join(root_folder, "bpe_tokenizers", "bpe_dnabert2")
        #     assert os.path.isdir(bpe_folder), f"Directory does not exist: {bpe_folder}"
        #     self.bpe = AutoTokenizer.from_pretrained(f"{bpe_folder}/")
        # elif bpe_type.__contains__("barcode"):
        #     length = bpe_type.split("_")[-1]
        #     bpe_folder = os.path.join(root_folder, "bpe_tokenizers", f"bpe_barcode_{length}")
        #     assert os.path.isdir(bpe_folder), f"Directory does not exist: {bpe_folder}"
        #     self.bpe = AutoTokenizer.from_pretrained(bpe_folder)
        # else:
        #     raise NotImplementedError(f"bpe_type {bpe_type} is  not supported.")

    def __call__(self, dna_sequence, offset=0) -> Tuple[list, list]:
        x = dna_sequence[offset:]
        tokens = self.bpe(x, padding=True, return_tensors="pt")["input_ids"]
        tokens[tokens == 2] = 3
        tokens[tokens == 1] = 2
        tokens[tokens == 0] = 1  # all the UNK + CLS have token of 1

        tokens = tokens[0].tolist()

        if len(tokens) > self.max_tokenized_len:
            att_mask = [1] * self.max_tokenized_len
            tokens = tokens[: self.max_tokenized_len]
        else:
            att_mask = [1] * (len(tokens)) + [0] * (self.max_tokenized_len - len(tokens))
            tokens = tokens + [1] * (self.max_tokenized_len - len(tokens))

        att_mask = torch.tensor(att_mask, dtype=torch.int32)
        tokens = torch.tensor(tokens, dtype=torch.int64)
        return tokens, att_mask


class DNADataset(Dataset):
    def __init__(
        self,
        file_path,
        dataset_format,
        k_mer,
        choose_indexes_set=None,        # Used for K-Fold Cross Validation
        stride=None,
        max_len=0,     # placeholder value. If 0, computes the actual max len in the dataset
        randomize_offset=False,
        tokenizer="kmer",
        bpe_path=None,
        tokenize_n_nucleotide=False,
        label_set=None,
    ):
        self.k_mer = k_mer
        self.stride = k_mer if stride is None else stride
        self.max_len = max_len
        self.randomize_offset = randomize_offset
        self.dataset_format = dataset_format

        self.choose_indexes_set = choose_indexes_set


        # Wish to work with fasta files
        if dataset_format not in ["fishes", "birds", "Cypraeidae", "Drosophila", "bats", "Inga", "beetle", "fish", "insect_dataset_species", "insect_dataset_genus", "unseen_insect_dataset", "unseen", "myco_genus", "myco_species", "fish_12S", "fish_12S_Noise"] and not dataset_format.startswith("GNe"):
            raise NotImplementedError(f"Dataset {dataset_format} not supported.")

        # Retrieval of the dataset barcodes
        if choose_indexes_set is not None:
            self.barcodes = [str(seq_record.seq).upper() for idx, seq_record in enumerate(SeqIO.parse(file_path, "fasta")) if idx in choose_indexes_set]
        else:
            self.barcodes = [str(seq_record.seq).upper() for seq_record in SeqIO.parse(file_path, "fasta")]
            # Print the number of sequences in the dataset
            print(f"There are {len(self.barcodes)} sequences in the dataset {file_path}")

        if max_len == 0:
            # Define the maximum length among all the retrieved barcodes
            max_len = np.max([len(barcode) for barcode in self.barcodes])
            print(f"Maximum length for the dataset barcodes: {max_len}")
            self.max_len = max_len


        if tokenizer == "kmer":
            # Vocabulary
            base_pairs = "ACGT"
            self.special_tokens = ["[MASK]", "[UNK]"]  # ["[MASK]", "[CLS]", "[SEP]", "[PAD]", "[EOS]", "[UNK]"]
            UNK_TOKEN = "[UNK]"

            if tokenize_n_nucleotide:
                # Encode kmers which contain N differently depending on where it is
                base_pairs += "N"
            kmers = ["".join(kmer) for kmer in product(base_pairs, repeat=self.k_mer)]

            # Separate between good (idx < 4**k) and bad k-mers (idx > 4**k) for prediction
            if tokenize_n_nucleotide:
                prediction_kmers = []
                other_kmers = []
                for kmer in kmers:
                    if "N" in kmer:
                        other_kmers.append(kmer)
                    else:
                        prediction_kmers.append(kmer)

                kmers = prediction_kmers + other_kmers

            kmer_dict = dict.fromkeys(kmers, 1)
            self.vocab = build_vocab_from_dict(kmer_dict, specials=self.special_tokens)
            self.vocab.set_default_index(self.vocab[UNK_TOKEN])
            self.vocab_size = len(self.vocab)
            self.tokenizer = KmerTokenizer(
                self.k_mer, self.vocab, max_len=self.max_len, stride=self.stride, padding=True
            )
        elif tokenizer == "bpe":
            self.tokenizer = BPETokenizer(padding=True, max_tokenized_len=self.max_len, bpe_path=bpe_path)
            self.vocab_size = self.tokenizer.bpe.vocab_size
        else:
            raise ValueError(f'Tokenizer "{tokenizer}" not recognized.')
        #df = pd.read_csv(file_path, sep="\t" if file_path.endswith(".tsv") else ",", keep_default_na=False)
        #self.barcodes = df["nucleotides"].to_list()


        seq_ids = []
        if dataset_format in ["birds", "fishes", "bats", "insect_dataset_species", "insect_dataset_genus", "unseen_insect_dataset", "fish_12S", "fish_12S_Noise"]:

            for record in SeqIO.parse(file_path, "fasta"):
                header = record.description       # !!! Was "record.id", but using id does not give the full species if we consider fishes!!!
                #label_id = header.split("|")[0]   # "13", which corresponds to the number of the sequence
                seq_id = header.split("|")[1]   # "A2", which corresponds to the species identifier
                
                #WARNING! ADDED FOR TESTING THE DATASET SENT BY PROF!!!
                if dataset_format in ["insect_dataset_species", "insect_dataset_genus", "unseen_insect_dataset", "fish_12S", "fish_12S_Noise"]:  # As they come from a .mat file and labels starts from 1
                #if seq_id.isdigit():
                    seq_id = int(seq_id) - 1
                
                seq_ids.append(seq_id)

        elif dataset_format in ["Cypraeidae", "Drosophila", "Inga"] or dataset_format.startswith("GNe"):

            for record in SeqIO.parse(file_path, "fasta"):
                header = record.description       # !!! Was "record.id", but using id does not give the full species if we consider fishes!!!
                #label_id = header.split("|")[2]
                seq_id = header.split("|")[1]
                seq_ids.append(seq_id)

        elif dataset_format in ["beetle", "fish"] :
            for idx, record in enumerate(SeqIO.parse(file_path, "fasta")):

                if self.choose_indexes_set is None:
                    raise ValueError(f"You can't avoid specifying the indices set when dealing with dataset {dataset_format}!")

                if idx in self.choose_indexes_set:
                    header = record.description
                    #label_id = header.split(",")[0]
                    seq_id = header.split(",")[1]
                    seq_ids.append(seq_id)

        elif dataset_format == "unseen":
            for record in SeqIO.parse(file_path, "fasta"):
                header = record.description
                seq_id = header.split("|")[1]   # Pos 1 for genus
                seq_ids.append(seq_id)

        elif dataset_format == "myco_genus":
            for record in SeqIO.parse(file_path, "fasta"):
                header = record.description
                seq_id = ""
                for elem in (header.split("|")[1]).split(";"):
                    if not elem.startswith("s__"):  # Take all the info (kingdom, ....)
                        seq_id += elem  # genus and species are identified with "g__" and "s__"
                        seq_id += " "
                seq_ids.append(seq_id)

        elif dataset_format == "myco_species":
            for record in SeqIO.parse(file_path, "fasta"):
                header = record.description
                #for elem in (header.split("|")[1]).split(";"):
                #    if elem.startswith("s__"):
                #        seq_id = elem  # genus and species are identified with "g__" and "s__"
                seq_id = header.split("|")[1]
                seq_ids.append(seq_id)

        else:
            raise NotImplementedError(f"Dataset {dataset_format} not supported.")


        if label_set is None:
            # For training set
           
            print("Label set was not already defined! Starting its computation...\n")

            print("NUMBER OF SEQUENCES FOR TRAIN SET:", len(self.barcodes))
            print("Example of barcode:", self.barcodes[0])

            self.labels, self.label_set = pd.factorize(pd.Series(seq_ids), sort=True)

            print("Min label:", min(self.labels))
            print("Max label:", max(self.labels))
            print("Label set size:", len(self.label_set))


            print(f"The dataset has {len(self.label_set)} different labels.")
            #print("Label set:", self.label_set)
            print(f"After factorization, there are {len(self.labels)} labels in the dataset.")

        else:

            print("Label set was already defined. Retrieving it...\n")

            print("NUMBER OF SEQUENCES FOR TEST SET:", len(self.barcodes))
            
            # Reuse mapping from training
            self.label_set = label_set
            label_to_idx = {lbl: i for i, lbl in enumerate(label_set)}
            self.labels = [label_to_idx.get(lbl, -1) for lbl in seq_ids]
            print(f"The dataset has {len(self.label_set)} different labels.")
            #print("Label set:", self.label_set)
            

            #print("Check if train set misses any label from test set:")
            missing_labels = set(seq_ids) - set(self.label_set)
            if len(missing_labels) > 0:
                print(f"Warning: The following labels are missing in the training set and will be assigned label -1: {missing_labels}")
            #else:
                #print("All labels from test set are present in training set.")

        self.num_labels = len(self.label_set)


    def __len__(self):
        return len(self.barcodes)

    def __getitem__(self, idx):
        if self.randomize_offset:
            offset = torch.randint(self.k_mer, (1,)).item()
        else:
            offset = 0
        processed_barcode, att_mask = self.tokenizer(self.barcodes[idx], offset=offset)
        label = torch.tensor(self.labels[idx], dtype=torch.int64)
        return processed_barcode, label, att_mask


def representations_from_df(df, target_level, model, tokenizer, dataset_name, mode=None, mask_rate=None):

    orders = df["order_name"].to_numpy()
    if dataset_name == "CANADA-1.5M":
        _label_set, y = np.unique(df[target_level], return_inverse=True)
    elif dataset_name == "BIOSCAN-5M":
        # _label_set = np.unique(df[target_level])
        y = df[target_level]
    else:
        raise NotImplementedError("Dataset format is not supported. Must be one of CANADA-1.5M or BIOSCAN-5M")

    dna_embeddings = []

    with torch.no_grad():
        for barcode in df["nucleotides"]:
            x, att_mask = tokenizer(barcode)

            x = x.unsqueeze(0).to(model.device)
            att_mask = att_mask.unsqueeze(0).to(model.device)
            x = model(x, att_mask).hidden_states[-1]
            # previous mean pooling
            # x = x.mean(1)
            # dna_embeddings.append(x.cpu().numpy())

            # updated mean pooling to account for the attention mask and padding tokens
            # sum the embeddings of the tokens (excluding padding tokens)
            sum_embeddings = (x * att_mask.unsqueeze(-1)).sum(1)  # (batch_size, hidden_size)
            # sum the attention mask (number of tokens in the sequence without considering the padding tokens)
            sum_mask = att_mask.sum(1, keepdim=True)
            # calculate the mean embeddings
            mean_embeddings = sum_embeddings / sum_mask  # (batch_size, hidden_size)

            dna_embeddings.append(mean_embeddings.cpu().numpy())

    print(f"There are {len(df)} points in the dataset")
    latent = np.array(dna_embeddings)
    latent = np.squeeze(latent, 1)
    print(latent.shape)
    return latent, y, orders


# def representations_from_df(df, target_level, model, tokenizer, dataset_name, mode="nonmask", mask_rate=0.5):
#
#     orders = df["order_name"].to_numpy()
#     if dataset_name == "CANADA-1.5M":
#         _label_set, y = np.unique(df[target_level], return_inverse=True)
#     elif dataset_name == "BIOSCAN-5M":
#         # _label_set = np.unique(df[target_level])
#         y = df[target_level]
#     else:
#         raise NotImplementedError("Dataset format is not supported. Must be one of CANADA-1.5M or BIOSCAN-5M")
#
#     dna_embeddings = []
#     print("mode", mode)
#     print("mask rate", mask_rate)
#
#     with torch.no_grad():
#         for barcode in df["nucleotides"]:
#             x, att_mask = tokenizer(barcode)
#
#             if mode == "drop":
#                 x, att_mask = tokenizer(barcode)
#                 x = x.unsqueeze(0).to(model.device)
#                 att_mask = att_mask.unsqueeze(0).to(model.device)
#
#                 random_mask = torch.rand(x.size())
#                 mask_token_ratio = mask_rate
#                 mask_ratio = 1
#                 dropped_tokens = random_mask < mask_token_ratio * mask_ratio
#                 att_mask[dropped_tokens] = 0
#
#                 x = model(x, att_mask).hidden_states[-1][~dropped_tokens]
#                 att_mask = att_mask[~dropped_tokens].unsqueeze(-1)
#
#                 sum_embeddings = (x * att_mask.unsqueeze(-1)).sum(1)  # (batch_size, hidden_size)
#                 # sum the attention mask (number of tokens in the sequence without considering the padding tokens)
#                 sum_mask = att_mask.sum(0, keepdim=True)
#                 # calculate the mean embeddings
#                 mean_embeddings = sum_embeddings / sum_mask  # (batch_size, hidden_size)
#
#                 dna_embeddings.append(mean_embeddings.cpu().numpy().reshape(-1))
#
#             elif mode == "combined":
#
#                 n_special_tokens = 2
#                 # print(x.size())
#                 random_mask = torch.rand(x.size())
#                 mask_token_ratio = mask_rate
#                 mask_ratio = 1
#                 masked_unseen_tokens = random_mask < mask_token_ratio * mask_ratio
#
#                 x = x.unsqueeze(0).to(model.device)
#                 att_mask = att_mask.unsqueeze(0).to(model.device)
#                 masked_unseen_tokens = masked_unseen_tokens.to(model.device)
#
#                 special_tokens_mask = x > (n_special_tokens - 1)
#                 masked_unseen_tokens_n = masked_unseen_tokens & special_tokens_mask
#
#                 x[masked_unseen_tokens_n] = 0
#
#                 x = model(x, att_mask).hidden_states[-1]
#
#                 sum_embeddings = (x * att_mask.unsqueeze(-1)).sum(1)  # (batch_size, hidden_size)
#                 # sum the attention mask (number of tokens in the sequence without considering the padding tokens)
#                 sum_mask = att_mask.sum(1, keepdim=True)
#                 # calculate the mean embeddings
#                 mean_embeddings = sum_embeddings / sum_mask  # (batch_size, hidden_size)
#
#                 dna_embeddings.append(mean_embeddings.cpu().numpy().reshape(-1))
#
#             elif mode == "mask":
#                 n_special_tokens = 2
#                 # print(x.size())
#                 random_mask = torch.rand(x.size())
#                 mask_token_ratio = 0.5
#                 mask_ratio = 1
#                 masked_unseen_tokens = random_mask < mask_token_ratio * mask_ratio
#                 # print(masked_unseen_tokens)
#
#                 x = x.unsqueeze(0).to(model.device)
#                 att_mask = att_mask.unsqueeze(0).to(model.device)
#                 masked_unseen_tokens = masked_unseen_tokens.to(model.device)
#
#                 special_tokens_mask = x > (n_special_tokens - 1)
#                 masked_unseen_tokens_n = masked_unseen_tokens & special_tokens_mask
#                 # print(masked_unseen_tokens_n)
#
#                 x[masked_unseen_tokens_n] = 0
#                 # att_mask[~masked_unseen_tokens_n] = 0
#                 x = model(x, att_mask).hidden_states[-1][masked_unseen_tokens_n]
#                 # print(x.shape)
#
#                 mean_embeddings = x.mean(0)
#
#                 # print(mean_embeddings.shape)
#                 dna_embeddings.append(mean_embeddings.cpu().numpy().reshape(-1))
#
#             elif mode == "nonmask":
#
#                 n_special_tokens = 2
#                 # print(x.size())
#                 random_mask = torch.rand(x.size())
#                 mask_token_ratio = 0.5
#                 mask_ratio = 1
#                 masked_unseen_tokens = random_mask < mask_token_ratio * mask_ratio
#                 # print(masked_unseen_tokens)
#
#                 x = x.unsqueeze(0).to(model.device)
#                 att_mask = att_mask.unsqueeze(0).to(model.device)
#                 masked_unseen_tokens = masked_unseen_tokens.to(model.device)
#
#                 special_tokens_mask = x > (n_special_tokens - 1)
#                 masked_unseen_tokens_n = masked_unseen_tokens & special_tokens_mask
#                 # print(masked_unseen_tokens_n)
#
#                 x[masked_unseen_tokens_n] = 0
#                 # att_mask[~masked_unseen_tokens_n] = 0
#                 x = model(x, att_mask).hidden_states[-1][~masked_unseen_tokens_n]
#
#                 mean_embeddings = x.mean(0)
#
#                 dna_embeddings.append(mean_embeddings.cpu().numpy().reshape(-1))
#             else:
#                 raise ValueError(f"Mode {mode} not recognized.")
#
#     print(f"There are {len(df)} points in the dataset")
#     latent = np.array(dna_embeddings)
#     # latent = np.squeeze(latent, 1)
#     print(latent.shape)
#     return latent, y, orders
